create function indexes_remote_size(schema_name_in name, table_name_in name, index_name_in name) returns bigint
    strict
    language plpgsql
as
$$
DECLARE
    total_bytes BIGINT;
BEGIN
    SELECT
        sum(entry.total_bytes)::bigint AS total_bytes
    INTO total_bytes
    FROM (
        SELECT
            s.node_name,
            _timescaledb_internal.ping_data_node (s.node_name) AS node_up
        FROM
            _timescaledb_catalog.hypertable AS ht,
            _timescaledb_catalog.hypertable_data_node AS s
        WHERE
            ht.schema_name = schema_name_in
            AND ht.table_name = table_name_in
            AND s.hypertable_id = ht.id
         ) AS srv
    JOIN LATERAL _timescaledb_internal.data_node_index_size(
    CASE WHEN srv.node_up THEN
        srv.node_name
    ELSE
        NULL
    END, schema_name_in, index_name_in) entry ON TRUE ;
    RETURN total_bytes;
END;
$$;

alter function indexes_remote_size(name, name, name) owner to postgres;

