create function interval_to_usec(chunk_interval interval) returns bigint
    immutable
    parallel safe
    language sql
as
$$
    SELECT (int_sec * 1000000)::bigint from extract(epoch from chunk_interval) as int_sec;
$$;

alter function interval_to_usec(interval) owner to postgres;

