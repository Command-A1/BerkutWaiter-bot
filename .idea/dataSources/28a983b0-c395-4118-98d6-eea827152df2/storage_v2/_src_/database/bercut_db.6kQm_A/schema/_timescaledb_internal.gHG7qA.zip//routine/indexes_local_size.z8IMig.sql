create function indexes_local_size(schema_name_in name, index_name_in name)
    returns TABLE(hypertable_id integer, total_bytes bigint)
    strict
    language plpgsql
as
$$
BEGIN
        RETURN QUERY
        SELECT ci.hypertable_id, sum(pg_relation_size(c.oid))::bigint
        FROM                                      
        pg_class c,
        pg_namespace n,
        _timescaledb_catalog.hypertable h,
        _timescaledb_catalog.chunk ch,
        _timescaledb_catalog.chunk_index ci
        WHERE ch.schema_name = n.nspname
            AND c.relnamespace = n.oid
            AND c.relname = ci.index_name
            AND ch.id = ci.chunk_id
            AND h.id = ci.hypertable_id
            AND h.schema_name = schema_name_in 
            AND ci.hypertable_index_name = index_name_in
        GROUP BY ci.hypertable_id; 
END;
$$;

alter function indexes_local_size(name, name) owner to postgres;

