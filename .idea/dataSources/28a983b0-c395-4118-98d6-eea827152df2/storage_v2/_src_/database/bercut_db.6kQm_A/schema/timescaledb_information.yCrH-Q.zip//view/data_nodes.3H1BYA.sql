create view data_nodes(node_name, owner, options) as
SELECT s.node_name,
       s.owner,
       s.options
FROM (SELECT srv.srvname                 AS node_name,
             srv.srvowner::regrole::name AS owner,
             srv.srvoptions              AS options
      FROM pg_foreign_server srv,
           pg_foreign_data_wrapper fdw
      WHERE srv.srvfdw = fdw.oid
        AND fdw.fdwname = 'timescaledb_fdw'::name) s;

alter table data_nodes
    owner to postgres;

grant select on data_nodes to public;

