create view continuous_aggregates
            (hypertable_schema, hypertable_name, view_schema, view_name, view_owner, materialized_only, materialization_hypertable_schema,
             materialization_hypertable_name, view_definition)
as
SELECT ht.schema_name            AS hypertable_schema,
       ht.table_name             AS hypertable_name,
       cagg.user_view_schema     AS view_schema,
       cagg.user_view_name       AS view_name,
       viewinfo.viewowner        AS view_owner,
       cagg.materialized_only,
       mat_ht.schema_name        AS materialization_hypertable_schema,
       mat_ht.table_name         AS materialization_hypertable_name,
       directview.viewdefinition AS view_definition
FROM _timescaledb_catalog.continuous_agg cagg,
     _timescaledb_catalog.hypertable ht,
     LATERAL ( SELECT c.oid,
                      pg_get_userbyid(c.relowner) AS viewowner
               FROM pg_class c
                        LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
               WHERE c.relkind = 'v'::"char"
                 AND c.relname = cagg.user_view_name
                 AND n.nspname = cagg.user_view_schema) viewinfo,
     LATERAL ( SELECT pg_get_viewdef(c.oid) AS viewdefinition
               FROM pg_class c
                        LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
               WHERE c.relkind = 'v'::"char"
                 AND c.relname = cagg.direct_view_name
                 AND n.nspname = cagg.direct_view_schema) directview,
     LATERAL ( SELECT hypertable.schema_name,
                      hypertable.table_name
               FROM _timescaledb_catalog.hypertable
               WHERE cagg.mat_hypertable_id = hypertable.id) mat_ht
WHERE cagg.raw_hypertable_id = ht.id;

alter table continuous_aggregates
    owner to postgres;

grant select on continuous_aggregates to public;

