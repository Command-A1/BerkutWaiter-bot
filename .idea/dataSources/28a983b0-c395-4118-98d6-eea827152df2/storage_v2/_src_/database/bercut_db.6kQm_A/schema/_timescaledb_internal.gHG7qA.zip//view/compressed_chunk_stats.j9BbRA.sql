create view compressed_chunk_stats
            (schema_name, table_name, chunk_schema, chunk_name, compression_status, uncompressed_heap_size, uncompressed_index_size,
             uncompressed_toast_size, uncompressed_total_size, compressed_heap_size, compressed_index_size, compressed_toast_size,
             compressed_total_size)
as
SELECT srcht.schema_name,
       srcht.table_name,
       srcch.schema_name                                                                      AS chunk_schema,
       srcch.table_name                                                                       AS chunk_name,
       CASE
           WHEN srcch.compressed_chunk_id IS NULL THEN 'Uncompressed'::text
           ELSE 'Compressed'::text
           END                                                                                AS compression_status,
       map.uncompressed_heap_size,
       map.uncompressed_index_size,
       map.uncompressed_toast_size,
       map.uncompressed_heap_size + map.uncompressed_toast_size + map.uncompressed_index_size AS uncompressed_total_size,
       map.compressed_heap_size,
       map.compressed_index_size,
       map.compressed_toast_size,
       map.compressed_heap_size + map.compressed_toast_size + map.compressed_index_size       AS compressed_total_size
FROM _timescaledb_catalog.hypertable srcht
         JOIN _timescaledb_catalog.chunk srcch
              ON srcht.id = srcch.hypertable_id AND srcht.compressed_hypertable_id IS NOT NULL AND srcch.dropped = false
         LEFT JOIN _timescaledb_catalog.compression_chunk_size map ON srcch.id = map.chunk_id;

alter table compressed_chunk_stats
    owner to postgres;

grant select on compressed_chunk_stats to public;

