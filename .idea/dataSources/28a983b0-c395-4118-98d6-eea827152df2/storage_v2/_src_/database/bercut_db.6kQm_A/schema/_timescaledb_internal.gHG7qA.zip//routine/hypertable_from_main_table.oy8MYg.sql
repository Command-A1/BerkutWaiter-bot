create function hypertable_from_main_table(table_oid regclass) returns _timescaledb_catalog.hypertable
    stable
    language sql
as
$$
    SELECT h.*
    FROM pg_class c
    INNER JOIN pg_namespace n ON (n.OID = c.relnamespace)
    INNER JOIN _timescaledb_catalog.hypertable h ON (h.table_name = c.relname AND h.schema_name = n.nspname)
    WHERE c.OID = table_oid;
$$;

alter function hypertable_from_main_table(regclass) owner to postgres;

