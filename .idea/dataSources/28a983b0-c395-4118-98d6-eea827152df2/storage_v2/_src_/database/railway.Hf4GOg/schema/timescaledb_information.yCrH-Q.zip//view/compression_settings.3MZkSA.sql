create view compression_settings
            (hypertable_schema, hypertable_name, attname, segmentby_column_index, orderby_column_index, orderby_asc, orderby_nullsfirst) as
SELECT ht.schema_name AS hypertable_schema,
       ht.table_name  AS hypertable_name,
       segq.attname,
       segq.segmentby_column_index,
       segq.orderby_column_index,
       segq.orderby_asc,
       segq.orderby_nullsfirst
FROM _timescaledb_catalog.hypertable_compression segq,
     _timescaledb_catalog.hypertable ht
WHERE segq.hypertable_id = ht.id
  AND (segq.segmentby_column_index IS NOT NULL OR segq.orderby_column_index IS NOT NULL)
ORDER BY ht.table_name, segq.segmentby_column_index, segq.orderby_column_index;

alter table compression_settings
    owner to postgres;

grant select on compression_settings to public;

