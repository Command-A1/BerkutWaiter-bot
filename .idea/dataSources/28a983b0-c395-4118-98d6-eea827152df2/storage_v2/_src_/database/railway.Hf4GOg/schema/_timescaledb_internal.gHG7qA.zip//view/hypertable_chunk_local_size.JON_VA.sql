create view hypertable_chunk_local_size
            (schema_name, table_name, hypertable_id, chunk_id, chunk_schema, chunk_name, total_bytes, index_bytes, toast_bytes, compressed_heap_size,
             compressed_index_size, compressed_toast_size)
as
SELECT h.schema_name,
       h.table_name,
       h.id                                                                                 AS hypertable_id,
       c.id                                                                                 AS chunk_id,
       c.schema_name                                                                        AS chunk_schema,
       c.table_name                                                                         AS chunk_name,
       pg_total_relation_size(format('%I.%I'::text, c.schema_name, c.table_name)::regclass) AS total_bytes,
       pg_indexes_size(format('%I.%I'::text, c.schema_name, c.table_name)::regclass)        AS index_bytes,
       pg_total_relation_size(pgc.reltoastrelid::regclass)                                  AS toast_bytes,
       map.compressed_heap_size,
       map.compressed_index_size,
       map.compressed_toast_size
FROM _timescaledb_catalog.hypertable h
         JOIN _timescaledb_catalog.chunk c ON h.id = c.hypertable_id AND c.dropped = false
         JOIN pg_class pgc ON pgc.relname = h.table_name
         JOIN pg_namespace pns ON pns.oid = pgc.relnamespace AND pns.nspname = h.schema_name
         LEFT JOIN _timescaledb_catalog.compression_chunk_size map ON map.chunk_id = c.id
WHERE pgc.relkind = 'r'::"char";

alter table hypertable_chunk_local_size
    owner to postgres;

grant select on hypertable_chunk_local_size to public;

