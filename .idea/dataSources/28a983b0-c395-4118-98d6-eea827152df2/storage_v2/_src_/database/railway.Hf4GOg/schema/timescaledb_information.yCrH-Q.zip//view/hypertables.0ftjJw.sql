create view hypertables
            (hypertable_schema, hypertable_name, owner, num_dimensions, num_chunks, compression_enabled, is_distributed, replication_factor,
             data_nodes, tablespaces)
as
SELECT ht.schema_name                   AS hypertable_schema,
       ht.table_name                    AS hypertable_name,
       t.tableowner                     AS owner,
       ht.num_dimensions,
       (SELECT count(1) AS count
        FROM _timescaledb_catalog.chunk ch
        WHERE ch.hypertable_id = ht.id) AS num_chunks,
       CASE
           WHEN ht.compression_state = 1 THEN true
           ELSE false
           END                          AS compression_enabled,
       CASE
           WHEN ht.replication_factor > 0 THEN true
           ELSE false
           END                          AS is_distributed,
       ht.replication_factor,
       dn.node_list                     AS data_nodes,
       srchtbs.tablespace_list          AS tablespaces
FROM _timescaledb_catalog.hypertable ht
         JOIN pg_tables t ON ht.table_name = t.tablename AND ht.schema_name = t.schemaname
         LEFT JOIN _timescaledb_catalog.continuous_agg ca ON ca.mat_hypertable_id = ht.id
         LEFT JOIN (SELECT tablespace.hypertable_id,
                           array_agg(tablespace.tablespace_name ORDER BY tablespace.id) AS tablespace_list
                    FROM _timescaledb_catalog.tablespace
                    GROUP BY tablespace.hypertable_id) srchtbs ON ht.id = srchtbs.hypertable_id
         LEFT JOIN (SELECT hypertable_data_node.hypertable_id,
                           array_agg(hypertable_data_node.node_name ORDER BY hypertable_data_node.node_name) AS node_list
                    FROM _timescaledb_catalog.hypertable_data_node
                    GROUP BY hypertable_data_node.hypertable_id) dn ON ht.id = dn.hypertable_id
WHERE ht.compression_state <> 2
  AND ca.mat_hypertable_id IS NULL;

alter table hypertables
    owner to postgres;

grant select on hypertables to public;

