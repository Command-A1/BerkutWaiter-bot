create view jobs
            (job_id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, config,
             next_start, hypertable_schema, hypertable_name)
as
SELECT j.id           AS job_id,
       j.application_name,
       j.schedule_interval,
       j.max_runtime,
       j.max_retries,
       j.retry_period,
       j.proc_schema,
       j.proc_name,
       j.owner,
       j.scheduled,
       j.config,
       js.next_start,
       ht.schema_name AS hypertable_schema,
       ht.table_name  AS hypertable_name
FROM _timescaledb_config.bgw_job j
         LEFT JOIN _timescaledb_catalog.hypertable ht ON ht.id = j.hypertable_id
         LEFT JOIN _timescaledb_internal.bgw_job_stat js ON js.job_id = j.id;

alter table jobs
    owner to postgres;

grant select on jobs to public;

