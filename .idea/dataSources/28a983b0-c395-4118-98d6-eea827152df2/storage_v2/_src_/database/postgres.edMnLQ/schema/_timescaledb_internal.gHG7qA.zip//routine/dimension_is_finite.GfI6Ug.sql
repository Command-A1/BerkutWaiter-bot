create function dimension_is_finite(val bigint) returns boolean
    immutable
    parallel safe
    language sql
as
$$
    --end values of bigint reserved for infinite
    SELECT val > (-9223372036854775808)::bigint AND val < 9223372036854775807::bigint
$$;

alter function dimension_is_finite(bigint) owner to postgres;

